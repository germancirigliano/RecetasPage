import React from 'react'

export const Edit = () => {
  return (
    <div>Edit</div>
  )
}

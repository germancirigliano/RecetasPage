import { RecetasGrid } from "../components/RecetasGrid"


export const LandingPage = () => {
    
    return <RecetasGrid/>
}